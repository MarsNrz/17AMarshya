<?php

    include 'libraries/database.php';

    $kode_barang = $_GET['kode_barang'];

    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        $kode_barang = $_GET['kode_barang'];

        $sql = "DELETE FROM barang WHERE kode_barang = '$kode_barang'";
        $result = $mysqli->query($sql);

        if ($result) {
            header("location: index_barang_tenan.php");
        } else {
            echo "Gagal menghapus data: " . $mysqli->error;}
    }

?>