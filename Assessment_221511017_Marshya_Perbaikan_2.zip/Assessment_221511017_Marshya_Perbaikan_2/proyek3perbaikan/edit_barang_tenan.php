<?php

    // include 'proyek3perbaikan/libraries/database.php';
    include 'libraries/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $kode_barang      = $_POST['kode_barang'];
        $kode_tenan       = $_POST['kode_tenan '];
        $nama_barang      = $_POST['nama_barang'];
        $satuan           = $_POST['satuan'];
        $harga_satuan     = $_POST['harga_satuan'];
        $stok             = $_POST['stok'];

        $sql = "UPDATE barang SET
                    -- kode_tenan  = '$kode_tenan ',
                    nama_barang = '$nama_barang',
                    satuan = '$satuan',
                    harga_satuan = '$harga_satuan',
                    stok = '$stok'
                    WHERE kode_barang = '$kode_barang'";

        $mysqli-> query($sql) or die ($mysqli->error);

        header("location:index_barang_tenan.php?kode_tenan=$kode_tenan");
    }

    $kode_barang = $_GET['kode_barang'];

    $sql = "select * from barang where kode_barang = '$kode_barang'";
    $q = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database
    $data_barang = $q->fetch_array();

    //cek jika data dari database kosong, maka kembali ke home (index.php)
    if (empty($data_barang)) {
        header("location:index.php");
    }

    include 'views/v_edit_barang_tenan.php';

?>