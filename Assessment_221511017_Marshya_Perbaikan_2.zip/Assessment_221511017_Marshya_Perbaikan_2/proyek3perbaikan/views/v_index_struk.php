<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Nota</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }

    .tombol-tambah-barang {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        border: 1px solid #060d5a;
        padding: 12px 34px;
        font-size: 13px;
        background: transparent;
        position: relative;
        cursor: pointer;
    }

    .tombol-tambah-barang:hover {
        border: 1px solid #060d5a;
        color: #fff;
        background: #060d5a;
        transition: 1s;
    }
</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <div>
        <section class="awalan">
            <table border="1" class="data">
                <?php
                    while ($nota = $data_nota->fetch_array()) {
                        while ($barang_nota = $data_barang_nota->fetch_array()) {
                ?>
                            <tr>
                                <td>Kode Nota</td>
                                <td><?php echo $nota ['kode_nota']; ?></td>
                            </tr>

                            <tr>
                                <td>Kode Tenan</td>
                                <td>Kode Kasir</td>
                                <td>Tanggal</td>
                            </tr>
                            <tr>
                                <td><?php echo $nota ['kode_tenan']; ?></td>
                                <td><?php echo $nota ['kode_kasir']; ?></td>
                                <td><?php echo $nota ['tgl_jam_nota']; ?></td>
                            </tr>

                            <tr>
                                <td>Kode Barang</td>
                                <td>Jumlah Barang</td>
                                <td>Total</td>
                            </tr>
                            <tr>
                                <td><?php echo $barang_nota ['kode_nota']; ?></td>
                                <td><?php echo $barang_nota ['kode_nota']; ?></td>
                                <td><?php echo $barang_nota ['kode_nota']; ?></td>
                            </tr>

                            <tr>
                                <td>Jumlah Belanja</td>
                                <td><?php echo $nota ['kode_nota']; ?></td>
                            </tr>

                            <tr>
                                <td>Diskon</td>
                                <td><?php echo $nota ['kode_nota']; ?></td>
                            </tr>

                            <tr>
                                <td>Grand Total</td>
                                <td><?php echo $nota ['kode_nota']; ?></td>
                            </tr>
                <?php
                        }
                    }
                ?>
            </table>
        </section>
    </div>

    
</body>

</html>