<?php 

    include 'libraries/database.php';

    $sql = "SELECT * FROM nota";
    $data_nota = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    if (!$data_nota) {
        die("Error menjalankan query: " . $mysqli->error);
    }

    include 'views/v_index_nota.php';

?>