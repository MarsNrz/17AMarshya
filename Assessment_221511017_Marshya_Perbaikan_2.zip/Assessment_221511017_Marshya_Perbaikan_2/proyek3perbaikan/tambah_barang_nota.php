<?php

    include 'libraries/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $kode_nota          = $_POST['kode_nota'];
        $kode_barang        = $_POST['kode_barang'];
        $jumlah_barang      = $_POST['jumlah_barang'];
        $harga_totalb       = $_POST['harga_totalb'];

        $sql = "INSERT INTO barang_nota (kode_nota, kode_barang, jumlah_barang, harga_totalb)
        VALUES ('$kode_nota', '$kode_barang', '$jumlah_barang', '$harga_totalb')";

        $mysqli-> query($sql) or die ($mysqli->error);

        header("location:index_barang_nota.php");
    }

    include 'views/v_tambah_barang_nota.php';

?>