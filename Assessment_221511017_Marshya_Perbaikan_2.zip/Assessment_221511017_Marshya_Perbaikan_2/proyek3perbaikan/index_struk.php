<?php

include 'libraries/database.php';

$kode_nota = $_GET['kode_nota'];

$sql = "SELECT * FROM nota WHERE kode_nota = '$kode_nota'";
$data_nota = $mysqli->query($sql);
//query adalah pesan yang diminta ke database

$sql = "SELECT * FROM barang_nota WHERE kode_nota = '$kode_nota'";
$data_barang_nota = $mysqli->query($sql);
//query adalah pesan yang diminta ke database

include 'views/v_index_struk.php';
?>