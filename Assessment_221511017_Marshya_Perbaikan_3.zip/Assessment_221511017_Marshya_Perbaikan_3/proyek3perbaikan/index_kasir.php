<?php

    include 'libraries/database.php';

    $sql = "SELECT * FROM kasir";
    $data_kasir = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    if (!$data_kasir) {
        die("Error menjalankan query: " . $mysqli->error);
    }

    include 'views/v_index_kasir.php';

?>