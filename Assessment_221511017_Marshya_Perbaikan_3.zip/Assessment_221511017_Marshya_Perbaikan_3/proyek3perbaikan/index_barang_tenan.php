<?php

    include 'libraries/database.php';
   
    $kode_tenan = $_GET['kode_tenan'];

    $sql = "SELECT * FROM barang WHERE kode_tenan = '$kode_tenan'";
    $data_barang = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    include 'views/v_index_barang_tenan.php';
?>

<!-- SELECT b.*, (stok-SUM(jumlah_barang)) AS stok_sisa
    FROM barang b 
    LEFT JOIN barang_nota bn ON b.kode_barang=bn.kode_barang 
    WHERE kode_tenan = '$kode_tenan'
    GROUP BY b.kode_barang -->