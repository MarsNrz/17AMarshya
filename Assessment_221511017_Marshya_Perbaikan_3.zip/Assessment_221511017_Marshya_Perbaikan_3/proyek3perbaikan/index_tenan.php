<?php

    include 'libraries/database.php';

    $sql = "select * from tenan";
    $data_tenan = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    if (!$data_tenan) {
        die("Error menjalankan query: " . $mysqli->error);
    }

    include 'views/v_index_tenan.php';

?>