<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Nota</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }

    .vki {
        text-align: left;
    }

    .vka {
        text-align: right;
    }

    .vt {
        text-align: center;
    }

</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <div>
        <section class="awalan">
            <table border="1" class="data">
                <?php
                    $nota = $data_nota->fetch_array();
                    $tenan = $data_tenan->fetch_array();
                    $kasir = $data_kasir->fetch_array();
                ?>

                    <tr>
                        <td class="vki">Kode Nota</td>
                        <td class="vki" colspan="4"><?php echo $nota ['kode_nota']; ?></td>
                    </tr>

                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>

                    <tr>
                        <td class="vki" colspan="2">Nama Tenan</td>
                        <td class="vki" colspan="2">Nama Kasir</td>
                        <td class="vki">Tanggal</td>
                    </tr>
                    <tr>
                        <td class="vki" colspan="2"><?php echo $tenan ['nama_tenan']; ?></td>
                        <td class="vki" colspan="2"><?php echo $kasir ['nama_kasir']; ?></td>
                        <td class="vki"><?php echo $nota ['tgl_nota']; ?></td>
                    </tr>

                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>

                    <tr>
                        <td class="vki">Kode Barang</td>
                        <td class="vki">Nama Barang</td>
                        <td class="vt">Qty</td>
                        <td class="vt">Satuan</td>
                        <td class="vt">Total</td>
                    </tr>

                <?php
                    while ($bn_b = $data_barang_nota->fetch_array()) {
                ?>
                        <tr>
                            <td class="vki"><?php echo $bn_b ['kode_barang']; ?></td>
                            <td class="vki"><?php echo $bn_b ['nama_barang']; ?></td>
                            <td class="vt"><?php echo $bn_b ['jumlah_barang']; ?></td>
                            <td class="vt"><?php echo $bn_b ['harga_satuan']; ?></td>
                            <td class="vt"><?php echo $bn_b ['harga_totalb']; ?></td>
                        </tr>

                        
                <?php
                    }
                ?>

                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>

                    <tr>
                        <td class="vki">Jumlah Belanja</td>
                        <td class="vka" colspan="4"><?php echo $nota ['jumlah_belanja']; ?></td>
                    </tr>

                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>

                    <tr>
                        <td class="vki">Diskon</td>
                        <td class="vka" colspan="4"><?php echo $nota ['diskon']; ?></td>
                    </tr>

                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>
                    <tr></tr>

                    <tr>
                        <td class="vki">Grand Total</td>
                        <td class="vka" colspan="4"><?php echo $nota ['total']; ?></td>
                    </tr>
            </table>
        </section>
    </div>

    
</body>

</html>