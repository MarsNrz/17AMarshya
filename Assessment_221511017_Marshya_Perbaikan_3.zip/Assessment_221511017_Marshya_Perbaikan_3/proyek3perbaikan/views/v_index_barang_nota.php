<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Nota</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }

    .data {
        border-collapse: collapse;
        font-size: 10pt;
        margin-left: auto;
        margin-right: auto;
    }

    td {
        padding: 7px;
        width: 145px;
        height: 25px;
    }

    .judul {
        background-color: lightblue;
        color: black;
        height: 30px;
    }

    .tombol-tambah-barang {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        border: 1px solid #060d5a;
        padding: 12px 34px;
        font-size: 13px;
        background: transparent;
        position: relative;
        cursor: pointer;
    }

    .tombol-tambah-barang:hover {
        border: 1px solid #060d5a;
        color: #fff;
        background: #060d5a;
        transition: 1s;
    }

    .tombol-lihat-struk {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        border: 1px solid #060d5a;
        padding: 12px 34px;
        font-size: 13px;
        background: transparent;
        position: relative;
        cursor: pointer;
    }

    .tombol-lihat-struk:hover {
        border: 1px solid #060d5a;
        color: #fff;
        background: #060d5a;
        transition: 1s;
    }
</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <div>
        <a href="tambah_barang_nota.php?kode_nota=<?= $kode_nota?>&kode_tenan=<?= $kode_tenan?>" class="tombol-tambah-barang">Tambah Data</a>

        <section class="awalan">
            <table border="1" class="data">
                <thead class="judul">
                    <tr>
                        <th>Kode Nota</th>
                        <th>Kode Barang</th>
                        <th>Jumlah Barang</th>
                        <th>Harga Satuan</th>
                        <th>Harga Total Barang</th>
                        <!-- <th>Action</th> -->
                    </tr>
                </thead>

                <tbody>
                    <?php
                        while ($barang_nota = $data_barang_nota->fetch_array()) {
                    ?>

                        <tr>
                            <td><?php echo $barang_nota ['kode_nota']; ?></td>
                            <td><?php echo $barang_nota ['kode_barang']; ?></td>
                            <td><?php echo $barang_nota ['jumlah_barang']; ?></td>
                            <td><?php echo $barang_nota ['harga_satuan']; ?></td>
                            <td><?php echo $barang_nota ['harga_totalb']; ?></td>
                            <!-- <td>
                                <a href="edit_barang_nota.php?kode_barang_nota=<?= $barang_nota ['kode_barang']?>">Edit</a>
                            </td>  -->
                        </tr>

                    <?php   
                        }
                    ?>
                </tbody>
            </table>
        </section>
        
        <a href="index_struk.php?kode_nota=<?= $kode_nota?>" class="tombol-lihat-struk">Lihat Struk</a>

    </div>

    
</body>

</html>