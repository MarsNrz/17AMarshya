<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Nota</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }

    .data {
        border-collapse: collapse;
        font-size: 10pt;
        margin-left: auto;
        margin-right: auto;
    }

    td {
        padding: 7px;
        width: 145px;
        height: 25px;
    }

    .judul {
        background-color: lightblue;
        color: black;
        height: 30px;
    }
</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="#">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <section class="awalan">
        <table border="1" class="data">
            <thead class="judul">
                <tr>
                    <th>Kode Transaksi</th>
                    <th>Kode Tenan</th>
                    <th>Kode Kasir</th>
                    <th>Tanggal Transaksi</th>
                    <th>Jumlah Belanjaan</th>
                    <th>Diskon (%)</th>
                    <th>Total Harga</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    while ($nota = $data_nota->fetch_array()) {
                ?>

                    <tr>
                        <td><?php echo $nota ['kode_nota']; ?></td>
                        <td><?php echo $nota ['kode_tenan']; ?></td>
                        <td><?php echo $nota ['kode_kasir']; ?></td>
                        <td><?php echo $nota ['tgl_nota']; ?></td>
                        <td><?php echo $nota ['jumlah_belanja']; ?></td>
                        <td><?php echo $nota ['diskon']; ?></td>
                        <td><?php echo $nota ['total']; ?></td>
                        <td>
                            <a href="index_barang_nota.php?kode_nota=<?= $nota ['kode_nota']?>&kode_tenan=<?= $nota ['kode_tenan']?>"></a> | 
                            <a href="index_struk.php?kode_nota=<?= $nota ['kode_nota']?>">Struk</a>
                        </td>
                    </tr>

                <?php
                    }
                ?>
            </tbody>
        </table>
    </section>
    
</body>

</html>