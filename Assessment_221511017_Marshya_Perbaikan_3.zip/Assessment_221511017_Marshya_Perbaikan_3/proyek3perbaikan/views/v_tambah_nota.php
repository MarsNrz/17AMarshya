<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }
</style>

<?php
    $action = 'tambah_nota.php';

    /*if (!empty($id_pendidikan)){
        $action = 'edit_pendidikan.php';
    }*/
?>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="#">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <section class="awalan">

        <h1 class="head">Nota Transaksi</h1>

        <form action="" method="post">
            <table>
                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>Kode Nota</tr>
                <tr><input type="text" name="kode_nota" value="<?= @$data_nota['kode_nota']?>"></tr>

                <tr>
                    <td>Kode Tenan</td>
                    <td>Kode Kasir</td>
                </tr>
                <tr>
                    <td>
                        <select name="kode_tenan">
                            <option>---</option>
                            <?php
                            include "database.php";
                            $query = mysqli_query($mysqli, "SELECT* FROM tenan") or die (mysqli_error($mysqli));
                            while($data_nota= mysqli_fetch_array($query)) {
                                echo "<option value=$data_nota[kode_tenan]> $data_nota[nama_tenan] </option>";
                            }
                            ?>
                        </select>
                    </td>
                    <td>
                        <select name="kode_kasir">
                            <option>---</option>
                            <?php
                            include "database.php";
                            $query = mysqli_query($mysqli, "SELECT* FROM kasir") or die (mysqli_error($mysqli));
                            while($data_nota = mysqli_fetch_array($query)) {
                                echo "<option value=$data_nota[kode_kasir]> $data_nota[nama_kasir] </option>";
                            }
                            ?>
                        </select>
                    </td>
                </tr>

                <!-- <tr>
                    <td>Jumlah Belanja</td>
                    <td><input type="text" name="jumlah_belanja" value="<?= @$data_nota['jumlah_belanja']?>"></td>
                </tr> -->

                <tr>
                    <td>Diskon</td>
                    <td><input type="text" name="diskon" value="<?= @$data_nota['diskon']?>"></td>
                </tr>

                <tr>
                    <td><input type="hidden" name="tgl_nota" value="<?php echo date("Y-m-d"); ?>"></td>
                </tr>

                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>
                    <td></td>
                    <td class="simpan"><input type="submit" name="Simpan"></td>
                </tr>
            </table>
        </form>

    </section>
    
</body>

</html>