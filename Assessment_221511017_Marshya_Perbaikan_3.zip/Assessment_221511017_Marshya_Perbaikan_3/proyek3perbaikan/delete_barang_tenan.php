<?php

    include 'libraries/database.php';

    $kode_barang = $_GET['kode_barang'];
    $kode_tenan = $_GET['kode_tenan'];

    if ($_SERVER['REQUEST_METHOD'] == 'GET'){
        $kode_barang = $_GET['kode_barang'];

        $sql = "DELETE FROM barang WHERE kode_barang = '$kode_barang'";
        $result = $mysqli->query($sql);

        // var_dump($kode_tenan);

        header("location: index_barang_tenan.php?kode_tenan=$kode_tenan");

        if (!$result) {
            echo "Gagal menghapus data: " . $mysqli->error;
        }
        
    }

?>