<?php

    include 'libraries/database.php';

    $kode_tenan = $_GET['kode_tenan'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $kode_barang      = $_POST['kode_barang'];
        // $kode_tenan       = $_POST['kode_tenan'];
        $nama_barang      = $_POST['nama_barang'];
        $satuan           = $_POST['satuan'];
        $harga_satuan     = $_POST['harga_satuan'];
        $stok             = $_POST['stok'];

        // var_dump($kode_tenan);

        $sql = "INSERT INTO barang (kode_barang, kode_tenan, nama_barang, satuan, harga_satuan, stok)
        VALUES ('$kode_barang', '$kode_tenan', '$nama_barang', '$satuan', '$harga_satuan', '$stok')";

        $mysqli-> query($sql) or die ($mysqli->error);

        header("location:index_barang_tenan.php?kode_tenan=$kode_tenan");
    }

    include 'views/v_tambah_barang_tenan.php';

?>