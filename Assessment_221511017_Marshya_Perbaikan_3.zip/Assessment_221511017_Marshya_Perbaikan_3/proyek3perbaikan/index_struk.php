<?php

    include 'libraries/database.php';
   
    $kode_nota = $_GET['kode_nota'];
    // $kode_tenan = $_GET['kode_tenan'];

    $sql1=
    "SELECT
        kode_tenan, 
        nama_tenan
    FROM tenan;";

    $data_tenan = $mysqli->query($sql1);

    $sql2=
    "SELECT
        kode_kasir, 
        nama_kasir
    FROM kasir;";

    $data_kasir = $mysqli->query($sql2);

    $sql3 = 
    "SELECT 
        b.kode_barang, 
        b.nama_barang, 
        b.harga_satuan,
        bn.kode_nota, 
        bn.kode_barang, 
        bn.jumlah_barang, 
        (b.harga_satuan*bn.jumlah_barang) AS harga_totalb 
    FROM barang b 
    LEFT JOIN barang_nota bn ON b.kode_barang=bn.kode_barang
    WHERE bn.kode_nota = '$kode_nota'
    GROUP BY bn.kode_barang;";

    $data_barang_nota = $mysqli->query($sql3);

    $sql4 = 
    "SELECT 
        n.kode_nota, 
        n.kode_tenan, 
        n.kode_kasir,
        n.tgl_nota, 
        SUM(bn.jumlah_barang) AS jumlah_belanja, 
        n.diskon, 
        ROUND (SUM(b.harga_satuan*bn.jumlah_barang) - SUM(b.harga_satuan*bn.jumlah_barang)*(n.diskon/100)) AS total 
    FROM nota n 
    LEFT JOIN barang_nota bn ON n.kode_nota=bn.kode_nota 
    LEFT JOIN barang b ON bn.kode_barang=b.kode_barang
    WHERE bn.kode_nota = '$kode_nota'
    GROUP BY n.kode_nota;";

    $data_nota = $mysqli->query($sql4);
    //query adalah pesan yang diminta ke database

    include 'views/v_index_struk.php';
?>

<!-- SELECT 
        n.kode_nota, 
        n.kode_tenan, 
        n.kode_kasir,
        n.tgl_nota, 
        SUM(bn.jumlah_barang) AS jumlah_belanja, 
        n.diskon, 
        ROUND (SUM(b.harga_satuan*bn.jumlah_barang) - SUM(b.harga_satuan*bn.jumlah_barang)*(n.diskon/100)) AS total, 
        bn.kode_nota, 
        bn.kode_barang, 
        bn.jumlah_barang, 
        (b.harga_satuan*bn.jumlah_barang) AS harga_totalb, 
        b.kode_barang, 
        b.kode_tenan, 
        b.nama_barang, 
        b.satuan, 
        b.harga_satuan, 
        b.stok
    FROM barang b 
    LEFT JOIN barang_nota bn ON b.kode_barang=bn.kode_barang
    LEFT JOIN nota n ON bn.kode_nota=n.kode_nota
    WHERE bn.kode_nota = '$kode_nota'
    GROUP BY n.kode_nota; -->