<?php

    include 'libraries/database.php';

    $kode_nota = $_GET['kode_nota'];
    $kode_tenan = $_GET['kode_tenan'];
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        // $kode_nota          = $_POST['kode_nota'];
        $kode_barang        = $_POST['kode_barang'];
        $jumlah_barang      = $_POST['jumlah_barang'];
        // $harga_totalb       = $_POST['harga_totalb'];

        // var_dump($kode_nota);

        $sql = "INSERT INTO barang_nota (kode_nota, kode_barang, jumlah_barang)
        VALUES ('$kode_nota', '$kode_barang', '$jumlah_barang')";

        $mysqli-> query($sql) or die ($mysqli->error);

        $query = "UPDATE barang SET
                stok = stok-$jumlah_barang
                WHERE kode_barang = '$kode_barang'";

        $mysqli-> query($query) or die ($mysqli->error);

        header("location:index_barang_nota.php?kode_nota=$kode_nota&kode_tenan=$kode_tenan");
    }

    include 'views/v_tambah_barang_nota.php';

?>