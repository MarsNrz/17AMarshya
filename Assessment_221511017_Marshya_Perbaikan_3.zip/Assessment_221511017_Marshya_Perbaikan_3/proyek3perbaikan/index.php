<?php 

    include 'libraries/database.php';

    $sql = "SELECT n.*, SUM(jumlah_barang) AS jumlah_belanja, ROUND (SUM(harga_satuan*jumlah_barang) - SUM(harga_satuan*jumlah_barang)*(diskon/100)) AS total 
    FROM nota n 
    LEFT JOIN barang_nota bn ON n.kode_nota=bn.kode_nota 
    LEFT JOIN barang b ON bn.kode_barang=b.kode_barang
    GROUP BY kode_nota;";

    $data_nota = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    if (!$data_nota) {
        die("Error menjalankan query: " . $mysqli->error);
    }

    // $query1 = "UPDATE nota SET
    //                 total = total+$gtotal
    //                 WHERE kode_nota = '$nota'";
    // $mysqli->query($query1) or die ($mysqli->error);

    include 'views/v_index_nota.php';

?>

<!-- SELECT n.*, SUM(jumlah_barang) AS jumlah_belanja, (SUM(harga_satuan*jumlah_barang) - SUM(harga_satuan*jumlah_barang)*(diskon/100)) AS total 
FROM nota n 
LEFT JOIN barang_nota bn ON n.kode_nota=bn.kode_nota 
LEFT JOIN barang b ON bn.kode_barang=b.kode_barang
GROUP BY kode_nota; -->