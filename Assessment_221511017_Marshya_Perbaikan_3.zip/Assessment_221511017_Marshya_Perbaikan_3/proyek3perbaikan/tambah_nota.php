<?php

    include 'libraries/database.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $kode_nota          = $_POST['kode_nota'];
        $kode_tenan         = $_POST['kode_tenan'];
        $kode_kasir         = $_POST['kode_kasir'];
        $tgl_nota           = $_POST['tgl_nota'];
        // $jumlah_belanja     = $_POST['jumlah_belanja'];
        $diskon             = $_POST['diskon'];
        // $total              = $_POST['total'];

        $sql = "INSERT INTO nota (kode_nota, kode_tenan, kode_kasir, tgl_nota, diskon)
        VALUES ('$kode_nota', '$kode_tenan', '$kode_kasir', '$tgl_nota', '$diskon')";

        $mysqli-> query($sql) or die ($mysqli->error);

        header("location:index_barang_nota.php?kode_nota=$kode_nota&kode_tenan=$kode_tenan");
    }

    include 'views/v_tambah_nota.php';

?>
