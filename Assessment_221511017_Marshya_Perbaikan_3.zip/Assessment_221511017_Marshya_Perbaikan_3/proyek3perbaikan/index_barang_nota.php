<?php

    include 'libraries/database.php';
   
    $kode_nota = $_GET['kode_nota'];
    $kode_tenan = $_GET['kode_tenan'];

    $sql = "SELECT bn.*, harga_satuan, (harga_satuan*jumlah_barang) AS harga_totalb 
    FROM barang b 
    LEFT JOIN barang_nota bn 
    ON b.kode_barang=bn.kode_barang
    WHERE bn.kode_nota = '$kode_nota'
    GROUP BY kode_barang;";

    $data_barang_nota = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    include 'views/v_index_barang_nota.php';
?>

<!-- SELECT bn.*, harga_satuan, (harga_satuan*jumlah_barang) AS harga_totalb 
    FROM barang b 
    LEFT JOIN barang_nota bn 
    ON b.kode_barang=bn.kode_barang
    WHERE bn.kode_nota = '$kode_nota'
    GROUP BY kode_barang; -->