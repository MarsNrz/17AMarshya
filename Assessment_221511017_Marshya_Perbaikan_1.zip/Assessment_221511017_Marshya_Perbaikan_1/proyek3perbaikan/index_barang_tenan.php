<?php

    include 'libraries/database.php';
   
    $kode_tenan = $_GET['kode_tenan'];

    $sql = "SELECT * FROM barang WHERE kode_tenan = '$kode_tenan'";
    $data_barang = $mysqli->query($sql);
    //query adalah pesan yang diminta ke database

    include 'views/v_index_barang_tenan.php';
?>