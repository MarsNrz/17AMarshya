<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang Nota</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }
</style>

<?php
    $action = 'tambah_nota.php';

    /*if (!empty($id_pendidikan)){
        $action = 'edit_pendidikan.php';
    }*/
?>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <section class="awalan">

        <h1 class="head">Barang Belian</h1>

        <form action="" method="post">
            <table>
                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>
                    <td>Kode Nota</td>
                    <td>Kode Barang</td>
                </tr>
                <tr>
                    <td><input type="text" name="kode_nota" value="<?= @$data_barang_nota['kode_nota']?>"></td>
                    <td><input type="text" name="kode_barang" value="<?= @$data_barang_nota['kode_barang']?>"></td>
                </tr>

                <tr>
                    <td>Jumlah per-Barang</td>
                    <td><input type="text" name="jumlah_barang" value="<?= @$data_barang_nota['jumlah_barang']?>"></td>
                </tr>

                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>
                    <td></td>
                    <td class="simpan"><input type="submit" name="Simpan"></td>
                </tr>
            </table>
        </form>

    </section>
    
</body>

</html>