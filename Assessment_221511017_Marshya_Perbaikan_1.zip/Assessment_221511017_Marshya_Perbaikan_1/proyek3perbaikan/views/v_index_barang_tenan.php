<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Tenan</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }

    .tombol-tambah-barang {
        display: inline-block;
        text-decoration: none;
        color: #fff;
        border: 1px solid #060d5a;
        padding: 12px 34px;
        font-size: 13px;
        background: transparent;
        position: relative;
        cursor: pointer;
    }

    .tombol-tambah-barang:hover {
        border: 1px solid #060d5a;
        color: #fff;
        background: #060d5a;
        transition: 1s;
    }
</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <div>
        <a href="tambah_barang_tenan.php" class="tombol-tambah-barang">Tambah Data</a>
        <section class="awalan">
            <table border="1" class="data">
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Satuan</th>
                        <th>Harga Satuan</th>
                        <th>Stok</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                        while ($barang = $data_barang->fetch_array()) {
                    ?>

                        <tr>
                            <td><?php echo $barang ['kode_barang']; ?></td>
                            <td><?php echo $barang ['nama_barang']; ?></td>
                            <td><?php echo $barang ['satuan']; ?></td>
                            <td><?php echo $barang ['harga_satuan']; ?></td>
                            <td><?php echo $barang ['stok']; ?></td>
                            <td>
                                <a href="edit_barang_tenan.php?kode_barang=<?= $barang ['kode_barang']?>">Edit</a> |
                                <a href="delete_barang_tenan.php?kode_barang=<?= $barang ['kode_barang']?>">Delete</a>
                            </td>
                        </tr>

                    <?php
                        }
                    ?>
                </tbody>
            </table>
        </section>
    </div>

    
</body>

</html>