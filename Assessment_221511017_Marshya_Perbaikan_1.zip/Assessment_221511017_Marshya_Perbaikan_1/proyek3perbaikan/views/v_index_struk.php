<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }
</style>

<?php
    $action = 'tambah_nota.php';

    /*if (!empty($id_pendidikan)){
        $action = 'edit_pendidikan.php';
    }*/
?>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="index_tenan.php">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="#">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <section class="awalan">

        <h1 class="head">Nota Transaksi</h1>

        <form action="" method="post">
            <table>
                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>Kode Nota</tr>
                <tr><input type="text" name="kode_nota" value="<?= @$data['kode_nota']?>"></tr>

                <tr>
                    <td>Jam</td>
                    <td>Tanggal</td>
                </tr>
                <tr>
                    <td><input type="text" name="jam_nota" value="<?= @$data['jam_nota']?>"></td>
                    <td><input type="text" name="tgl_nota" value="<?= @$data['tgl_nota']?>"></td>
                </tr>

                <tr>
                    <td>Kode Tenan</td>
                    <td>Kode Kasir</td>
                </tr>
                <tr>
                    <td><input type="text" name="kode_tenan" value="<?= @$data['kode_tenan']?>"></td>
                    <td><input type="text" name="kode_kasir" value="<?= @$data['kode_kasir']?>"></td>
                </tr>

                <tr>
                    <td>Jumlah Belanja</td>
                    <td><input type="text" name="jumlah_belanja" value="<?= @$data['jumlah_belanja']?>"></td>
                </tr>

                <tr>
                    <td>Diskon</td>
                    <td><input type="text" name="diskon" value="<?= @$data['diskon']?>"></td>
                </tr>

                <tr>
                    <td>Total Harga</td>
                    <td><input type="text" name="total" value="<?= @$data['total']?>"></td>
                </tr>

                <tr></tr>
                <tr></tr>
                <tr></tr>
                <tr></tr>

                <tr>
                    <td></td>
                    <td class="simpan"><input type="submit" name="Simpan"></td>
                </tr>
            </table>
        </form>

    </section>
    
</body>

</html>