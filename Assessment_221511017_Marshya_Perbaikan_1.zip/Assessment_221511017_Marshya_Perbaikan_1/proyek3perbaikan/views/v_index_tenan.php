<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenan</title>
</head>

<style>
    body {
        background-image: url(bg.jpg);
        background-repeat: no-repeat;
        background-size: 1280px;
    }

    .header {
        background-color: steelblue;
        color: white;
    }

    .logo {
        font-size: 30px;
    }

    .menu {
        float: right;
        margin: 0 5px;
        padding: 10 10px;
        color: white;
        text-decoration: none;
        display: block;
    }

    .awalan {
        color: white;
    }
</style>

<body>

    <nav class="header">
        <label class="logo">
            <h1>PUJASERA</h1>
        </label>
        <table class="menu">
            <tr>
                <td><a href="index.php">REKAP TRANSAKSI</a></td>
                <td><a href="#">DATA TENAN</a></td>
                <td><a href="index_kasir.php">DATA KASIR</a></td>
                <td><a href="tambah_nota.php">TRANSAKSI</a></td>
            </tr>
        </table>
    </nav>

    <section class="awalan">
        <table border="1" class="data">
            <thead>
                <tr>
                    <th>Kode Tenan</th>
                    <th>Nama Tenan</th>
                    <th>Nomor Telpon</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
                <?php
                    /*$i = 1;*/
                    while ($tenan = $data_tenan->fetch_array()) {
                ?>

                    <tr>
                        <td><?php echo $tenan ['kode_tenan']; ?></td>
                        <td><?php echo $tenan ['nama_tenan']; ?></td>
                        <td><?php echo $tenan ['hp_tenan']; ?></td>
                        <td><a href="index_barang_tenan.php?kode_tenan=<?= $tenan ['kode_tenan']?>">Barang</a></td>
                    </tr>

                <?php
                    }
                ?>
            </tbody>
        </table>
    </section>
    
</body>

</html>