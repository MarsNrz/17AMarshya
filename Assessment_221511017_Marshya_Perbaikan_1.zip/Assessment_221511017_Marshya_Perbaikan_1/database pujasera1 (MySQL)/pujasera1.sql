-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2024 at 05:04 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pujasera1`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `kode_barang` varchar(255) NOT NULL,
  `kode_tenan` varchar(255) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `satuan` varchar(255) NOT NULL,
  `harga_satuan` bigint(20) NOT NULL,
  `stok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`kode_barang`, `kode_tenan`, `nama_barang`, `satuan`, `harga_satuan`, `stok`) VALUES
('BRG01701_01', 'TN01701', 'Ayam Baka', 'ppp', 555, 111),
('BRG01701_03', 'TN01701', 'afefcrf', 'ewfcvsAef', 348888, 11),
('BRG01702_01', 'TN01702', 'Thai Tea (S)', 'gelas', 5000, 123),
('BRG01702_02', 'TN01702', 'jeruk', 'pot', 2341, 12),
('BRG01702_03', 'TN01702', 'gvfgbnhn', 'fghj', 5678, 9),
('BRG01703_01', 'TN01703', 'Baso Beranak', 'mangkok', 15000, 200);

-- --------------------------------------------------------

--
-- Table structure for table `barang_nota`
--

CREATE TABLE `barang_nota` (
  `kode_nota` varchar(255) NOT NULL,
  `kode_barang` varchar(255) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_totalb` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang_nota`
--

INSERT INTO `barang_nota` (`kode_nota`, `kode_barang`, `jumlah_barang`, `harga_totalb`) VALUES
('NT01701', 'BRG01701_01', 2, 0),
('NT01704', 'BRG01701_03', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `kasir`
--

CREATE TABLE `kasir` (
  `kode_kasir` varchar(255) NOT NULL,
  `nama_kasir` varchar(255) NOT NULL,
  `hp_kasir` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kasir`
--

INSERT INTO `kasir` (`kode_kasir`, `nama_kasir`, `hp_kasir`) VALUES
('KS01701', 'Aulia Nurul Fuziah', '0852-3456-4321'),
('KS01702', 'Laila Rifqah Jauza Salma', '0858-9475-9296'),
('KS01703', 'Haninda Aulia', '0823-9047-6516'),
('KS01704', 'Nazla Maura Fahmi', '0864-7863-7134'),
('KS01705', 'Lutfia Fatma', '0857-6023-9757');

-- --------------------------------------------------------

--
-- Table structure for table `nota`
--

CREATE TABLE `nota` (
  `kode_nota` varchar(255) NOT NULL,
  `kode_tenan` varchar(255) NOT NULL,
  `kode_kasir` varchar(255) NOT NULL,
  `tgl_jam_nota` timestamp NOT NULL DEFAULT current_timestamp(),
  `jumlah_belanja` int(11) NOT NULL,
  `diskon` int(11) NOT NULL,
  `total` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `nota`
--

INSERT INTO `nota` (`kode_nota`, `kode_tenan`, `kode_kasir`, `tgl_jam_nota`, `jumlah_belanja`, `diskon`, `total`) VALUES
('NT01701', 'TN01701', 'KS01701', '2024-01-02 07:51:37', 2, 0, 0),
('NT01702', 'TN01702', 'KS01703', '0000-00-00 00:00:00', 1, 0, 0),
('NT01703', 'TN01703', 'KS01702', '0000-00-00 00:00:00', 1, 0, 0),
('NT01704', 'TN01701', 'KS01704', '0000-00-00 00:00:00', 2, 0, 0),
('NT01705', 'TN01702', 'KS01703', '0000-00-00 00:00:00', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tenan`
--

CREATE TABLE `tenan` (
  `kode_tenan` varchar(255) NOT NULL,
  `nama_tenan` varchar(255) NOT NULL,
  `hp_tenan` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tenan`
--

INSERT INTO `tenan` (`kode_tenan`, `nama_tenan`, `hp_tenan`) VALUES
('TN01701', 'Ayam Bakar Bu Ijah', '0813-1300-8357'),
('TN01702', 'ES Zegerrr', '0823-8477-6364'),
('TN01703', 'Baso & Mie Ayam Maknyos', '0834-8757-09137'),
('TN01704', 'Pasakan Sunda', '0886-4728-56412'),
('TN01705', 'Padang Payakumbuah', '0883-7258-79874');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`kode_barang`),
  ADD KEY `kode_tenan` (`kode_tenan`);

--
-- Indexes for table `barang_nota`
--
ALTER TABLE `barang_nota`
  ADD KEY `kode_barang` (`kode_barang`),
  ADD KEY `kode_nota` (`kode_nota`);

--
-- Indexes for table `kasir`
--
ALTER TABLE `kasir`
  ADD PRIMARY KEY (`kode_kasir`);

--
-- Indexes for table `nota`
--
ALTER TABLE `nota`
  ADD PRIMARY KEY (`kode_nota`),
  ADD KEY `kode_tenan` (`kode_tenan`),
  ADD KEY `kode_kasir` (`kode_kasir`);

--
-- Indexes for table `tenan`
--
ALTER TABLE `tenan`
  ADD PRIMARY KEY (`kode_tenan`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`kode_tenan`) REFERENCES `tenan` (`kode_tenan`);

--
-- Constraints for table `barang_nota`
--
ALTER TABLE `barang_nota`
  ADD CONSTRAINT `barang_nota_ibfk_1` FOREIGN KEY (`kode_barang`) REFERENCES `barang` (`kode_barang`),
  ADD CONSTRAINT `barang_nota_ibfk_2` FOREIGN KEY (`kode_nota`) REFERENCES `nota` (`kode_nota`);

--
-- Constraints for table `nota`
--
ALTER TABLE `nota`
  ADD CONSTRAINT `nota_ibfk_1` FOREIGN KEY (`kode_tenan`) REFERENCES `tenan` (`kode_tenan`),
  ADD CONSTRAINT `nota_ibfk_2` FOREIGN KEY (`kode_kasir`) REFERENCES `kasir` (`kode_kasir`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
